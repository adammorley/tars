#!/bin/bash

#./android-tools/emulator/emulator -ports 5554,5555 -avd MyAVD -no-window -no-audio -gpu swiftshader_indirect -memory 128 -qemu -m size=128M -mem-prealloc

# cold boot
#./android-tools/emulator/emulator  -avd emuTest -no-boot-anim -noaudio -gpu off -no-boot-anim -no-snapshot-load  -memory 2048 -qemu -m size=2048M -mem-prealloc
# warm boot
./android-tools/emulator/emulator  -avd emuTest -no-boot-anim -noaudio -gpu off -wipe-data -memory 1024 -qemu -m size=1024M -mem-prealloc 

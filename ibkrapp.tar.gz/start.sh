#!/bin/bash
/snap/bin/anbox launch  --action=android.intent.action.MAIN --package=atws.app --component=atws.activity.launcher.LauncherActivity

#!/bin/bash

sudo modprobe ashmem_linux
sudo modprobe binder_linux
lsmod |grep _linux
xhost +
adb start-server
ps -ef |grep adb
anbox session-manager --software-rendering
